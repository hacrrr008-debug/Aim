Carrom Auto Aim Demo — Android Studio Project

এটি একটি buildable Android Studio source project; এখানে APK আগে থেকে compile করা নেই।

Build করার ধাপ:
1. ZIP extract করুন।
2. Android Studio-তে folder-টি Open করুন।
3. Gradle sync শেষ হতে দিন। Android SDK Platform 35 এবং JDK 17 লাগবে।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।
5. APK সাধারণত app/build/outputs/apk/debug/app-debug.apk-এ তৈরি হবে।

ফোনে:
1. APK install করুন।
2. অ্যাপ খুলে Accessibility Settings খুলুন।
3. Carrom Auto Aim Demo Service নিজে থেকে enable করুন।
4. Auto Aim toggle ডিফল্টে OFF থাকে। ভুল gesture হতে পারে বলে striker position ঠিকভাবে calibrate না করা পর্যন্ত ON করবেন না।

গুরুত্বপূর্ণ সীমাবদ্ধতা:
- বর্তমান findStrikerOnScreen() শুধু screen-এর 82% উচ্চতায় bottom-center অনুমান করে।
- এটি আসল striker শনাক্ত করে না; তাই এটি পূর্ণাঙ্গ/নির্ভরযোগ্য auto-aim নয়।
- বাস্তব detection করতে screen capture permission (MediaProjection) ও image-processing logic আলাদাভাবে যোগ করতে হবে।
- Gesture API Android 7.0 (API 24) বা নতুন সংস্করণ চায়।
- Accessibility permission শক্তিশালী অনুমতি; শুধু নিজের পরীক্ষার জন্য বুঝে-শুনে চালু করুন।
