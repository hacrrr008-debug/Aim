package com.carrom.hack.autoaim;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.SharedPreferences;
import android.graphics.Path;
import android.graphics.Point;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;

public class CarromAutoAimService extends AccessibilityService {
    private static final String PREFS = "carrom_autoaim_settings";
    private static final String KEY_ENABLED = "auto_aim_enabled";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private WindowManager windowManager;
    private int screenWidth;
    private int screenHeight;
    private boolean gesturePending;
    private long lastGestureTime;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        updateScreenSize();
    }

    private void updateScreenSize() {
        if (windowManager == null) {
            windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        }
        if (windowManager == null) return;

        Display display = windowManager.getDefaultDisplay();
        DisplayMetrics metrics = new DisplayMetrics();
        display.getRealMetrics(metrics);
        screenWidth = metrics.widthPixels;
        screenHeight = metrics.heightPixels;
    }

    private boolean isAutoAimEnabled() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        return prefs.getBoolean(KEY_ENABLED, false);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || !isAutoAimEnabled() || gesturePending) return;

        if (event.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            long now = System.currentTimeMillis();
            if (now - lastGestureTime < 1500) return;
            handler.postDelayed(this::executeAutoAim, 500);
        }
    }

    private void executeAutoAim() {
        if (!isAutoAimEnabled() || gesturePending) return;

        updateScreenSize();
        if (screenWidth <= 0 || screenHeight <= 0) return;

        Point striker = findStrikerOnScreen();
        if (striker == null) return;

        // Demo target only. Replace with a user-selected target after calibration.
        Point target = new Point(screenWidth / 2, screenHeight / 2);
        double dx = target.x - striker.x;
        double dy = target.y - striker.y;
        double distance = Math.hypot(dx, dy);
        if (distance < 1) return;

        double pullBack = Math.min(distance * 0.30,
                Math.min(screenWidth, screenHeight) * 0.12);
        double angle = Math.atan2(dy, dx);

        Point dragStart = new Point(
                clamp((int) (striker.x - Math.cos(angle) * pullBack), 0, screenWidth - 1),
                clamp((int) (striker.y - Math.sin(angle) * pullBack), 0, screenHeight - 1)
        );

        performSwipe(dragStart, striker);
    }

    /**
     * Placeholder only: games drawing the board in Canvas/OpenGL usually do
     * not expose striker objects as accessibility nodes. This is NOT detection.
     */
    private Point findStrikerOnScreen() {
        if (screenWidth <= 0 || screenHeight <= 0) return null;
        return new Point(screenWidth / 2, (int) (screenHeight * 0.82f));
    }

    private void performSwipe(Point start, Point end) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return;

        Path path = new Path();
        path.moveTo(start.x, start.y);
        path.lineTo(end.x, end.y);

        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0, 250))
                .build();

        gesturePending = true;
        boolean sent = dispatchGesture(gesture, new GestureResultCallback() {
            @Override
            public void onCompleted(GestureDescription description) {
                gesturePending = false;
                lastGestureTime = System.currentTimeMillis();
            }

            @Override
            public void onCancelled(GestureDescription description) {
                gesturePending = false;
            }
        }, handler);

        if (!sent) gesturePending = false;
    }

    private int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(value, max));
    }

    @Override
    public void onInterrupt() {
        gesturePending = false;
        handler.removeCallbacksAndMessages(null);
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        gesturePending = false;
        super.onDestroy();
    }
}
