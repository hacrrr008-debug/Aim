package com.carrom.hack.autoaim;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.Settings;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final String PREFS = "carrom_autoaim_settings";
    private static final String KEY_ENABLED = "auto_aim_enabled";
    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (20 * getResources().getDisplayMetrics().density);
        layout.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("Carrom Auto Aim Demo");
        title.setTextSize(24);
        layout.addView(title);

        TextView warning = new TextView(this);
        warning.setText(
            "পরীক্ষামূলক সংস্করণ। Striker এখনো ক্যামেরা/স্ক্রিন থেকে শনাক্ত হয় না; " +
            "শুধু নিচের দিকে একটি আনুমানিক অবস্থান ব্যবহার করা হয়। তাই গেমে চালু করলে " +
            "ভুল জায়গায় gesture হতে পারে। প্রথমে বন্ধ রাখুন।"
        );
        warning.setTextSize(16);
        warning.setPadding(0, pad, 0, pad);
        layout.addView(warning);

        status = new TextView(this);
        status.setTextSize(16);
        layout.addView(status);

        Button accessibility = new Button(this);
        accessibility.setText("Accessibility Settings খুলুন");
        accessibility.setOnClickListener(v ->
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        );
        layout.addView(accessibility);

        Button toggle = new Button(this);
        toggle.setText("Auto Aim পরীক্ষামূলকভাবে ON/OFF");
        toggle.setOnClickListener(v -> {
            SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
            boolean next = !prefs.getBoolean(KEY_ENABLED, false);
            prefs.edit().putBoolean(KEY_ENABLED, next).apply();
            updateStatus();
        });
        layout.addView(toggle);

        TextView note = new TextView(this);
        note.setText(
            "ব্যবহার: Accessibility Settings-এ গিয়ে Carrom Auto Aim Demo Service " +
            "নিজে থেকে চালু করুন। তারপর এই অ্যাপে ফিরে এসে প্রয়োজন হলে পরীক্ষামূলক " +
            "gesture চালু করুন। বন্ধ করতে toggle OFF করুন অথবা service disable করুন।"
        );
        note.setPadding(0, pad, 0, 0);
        note.setTextSize(14);
        layout.addView(note);

        setContentView(layout, new ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ));
        updateStatus();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateStatus();
    }

    private void updateStatus() {
        boolean enabled = getSharedPreferences(PREFS, MODE_PRIVATE)
                .getBoolean(KEY_ENABLED, false);
        status.setText("পরীক্ষামূলক Auto Aim: " + (enabled ? "ON" : "OFF"));
    }
}
